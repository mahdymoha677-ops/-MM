# TikTok MM — مشروع جاهز للتحويل إلى APK

هذا المشروع يحوّل نسخة Web من TikTok MM إلى تطبيق Android باستخدام WebView.

## المطلوب للبناء
- Android Studio حديث
- JDK متوافق مع Android Gradle Plugin
- فتح مجلد المشروع `TikTokMM_APK_READY`
- Build > Build APK(s)

## ملاحظة
النسخة الحالية ما زالت تعتمد على التخزين المحلي داخل التطبيق. الحسابات ليست خدمة إنترنت متعددة المستخدمين بعد.
